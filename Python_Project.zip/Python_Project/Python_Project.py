
import csv
from datetime import datetime
from pprint import pprint

import seaborn as sns

def print_first_point(filename):


    city = filename.split('-')[0].split('/')[-1]
    print('\nCity: {}'.format(city))

    with open(filename, 'r') as f_in:

        trip_reader =csv.DictReader(f_in)


        first_trip = next(trip_reader)


        pprint(first_trip)


    return (city, first_trip)

data_files = ['../input/NYC-CitiBike-2016.csv',
              '../input/Chicago-Divvy-2016.csv',
              '../input/Washington-CapitalBikeshare-2016.csv',]

example_trips = {}
for data_file in data_files:
    city, first_trip = print_first_point(data_file)
    example_trips[city] = first_trip

def duration_in_mins(datum, city):
    if city=="Washington":
        duration = (float(datum['Duration (ms)'])*(0.001))/60
    else:
        duration = (float(datum['tripduration']))/60
    return duration

tests = {'NYC': 13.9833,
         'Chicago': 15.4333,
         'Washington': 7.1231}

for city in tests:
    assert abs(duration_in_mins(example_trips[city], city) - tests[city]) < .001

def time_of_trip(datum, city):
    if city=="NYC":
        starttime = datum['starttime']
        s1 = datetime.strptime(starttime, '%m/%d/%Y %H:%M:%S')
        return(s1.month,s1.hour,s1.strftime('%A'))

    elif city=="Washington":
        starttime = datum['Start date']
        s1 = datetime.strptime(starttime, '%m/%d/%Y %H:%M')
        return(s1.month,s1.hour,s1.strftime('%A'))

    elif city=="Chicago":
        starttime = datum['starttime']
        s1 = datetime.strptime(starttime, '%m/%d/%Y %H:%M')
        return(s1.month,s1.hour,s1.strftime('%A'))
tests = {'NYC': (1, 0, 'Friday'),
         'Chicago': (3, 23, 'Thursday'),
         'Washington': (3, 22, 'Thursday')}

for city in tests:
    assert time_of_trip(example_trips[city], city) == tests[city]

def type_of_user(datum, city):
    if city=="NYC" or city=="Chicago":
        user_type = datum['usertype']
    elif city=="Washington":
        if datum['Member Type']=="Registered":
            user_type = "Subscriber"
        else:
            user_type = "Customer"

    return user_type

tests = {'NYC': 'Customer',
         'Chicago': 'Subscriber',
         'Washington': 'Subscriber'}

for city in tests:
    assert type_of_user(example_trips[city], city) == tests[city]

def condense_data(in_file, out_file, city):
    with open(out_file, 'w') as f_out, open(in_file, 'r') as f_in:
        out_colnames = ['duration', 'month', 'hour', 'day_of_week', 'user_type']
        trip_writer = csv.DictWriter(f_out, fieldnames = out_colnames)
        trip_writer.writeheader()

        trip_reader = csv.DictReader(f_in)
        for row in trip_reader:
            new_point = {}
            new_point['duration'] = duration_in_mins(row,city)
            new_point['month'],new_point['hour'],new_point['day_of_week'] = time_of_trip(row,city)
            new_point['user_type'] = type_of_user(row,city)
            f_out.write(str(new_point['duration']))
            f_out.write(",")
            f_out.write(str(new_point['month']))
            f_out.write(",")
            f_out.write(str(new_point['hour']))
            f_out.write(",")
            f_out.write(str(new_point['day_of_week']))
            f_out.write(",")
            f_out.write(str(new_point['user_type']))
            f_out.write("\n")
city_info = {'Washington': {'in_file': '../input/Washington-CapitalBikeshare-2016.csv',
                            'out_file': '../working/Washington-2016-Summary.csv'},
             'Chicago': {'in_file': '../input/Chicago-Divvy-2016.csv',
                         'out_file': '../working/Chicago-2016-Summary.csv'},
             'NYC': {'in_file': '../input/NYC-CitiBike-2016.csv',
                     'out_file': '../working/NYC-2016-Summary.csv'}}

for city, filenames in city_info.items():
    condense_data(filenames['in_file'], filenames['out_file'], city)
    print_first_point(filenames['out_file'])


def number_of_trips(filename):
    with open(filename, 'r') as f_in:
        reader = csv.DictReader(f_in)

        n_subscribers = 0
        n_customers = 0

        for row in reader:
            if row['user_type'] == 'Subscriber':
                n_subscribers += 1
            else:
                n_customers += 1

        n_total = n_subscribers + n_customers

        return(n_subscribers, n_customers, n_total)

data_file = ['../working//Washington-2016-Summary.csv', '../working//Chicago-2016-Summary.csv', '../working//NYC-2016-Summary.csv']
for datafile in data_file:
    n_subscribers,n_customers,n_total = number_of_trips(datafile)
    sub_p = (n_subscribers / n_total)*100
    cus_p = (n_customers / n_total)*100
    city = datafile.split('-')[0].split('/')[-1]
    print('In ' + city +' city, the total no. of Subscribers are ' + str(n_subscribers) +' ('+ str(abs(sub_p)) +'%)' + ', Customers are ' + str(n_customers)+' ('+ str(abs(cus_p)) +'%)' + ' and total no. of rides is ' + str(n_total) + '\n')

def trip_length(filename):
    total_ride = 0
    s = 0
    t_time = 0
    with open(filename,'r') as fin:
        reader = csv.DictReader(fin)
        for row in reader:
            total_ride = total_ride + 1
            duration = float(row['duration'])
            t_time = t_time + duration
            if duration>30:
                s = s + 1

        avg = (t_time/total_ride)
        p = (s/total_ride)

        return (t_time,total_ride,avg,p)

data_file = ['../working//Washington-2016-Summary.csv', '../working//Chicago-2016-Summary.csv', '../working//NYC-2016-Summary.csv']
for datafile in data_file:
    t_time,total,avg,p  = trip_length(datafile)
    city = datafile.split('-')[0].split('/')[-1]
    print("In "+city+" City: ")
    print("The Average Trip Length Is: "+ str(avg))
    print("Proportion of rides longer than 30 min: "+ str(p)+"\n")

def ridership(filename):
    with open(filename,'r') as fin:
        reader = csv.DictReader(fin)
        s = 0
        c = 0
        s_duration = 0
        c_duration = 0
        for row in reader:
            user_type = row['user_type']
            duration = float(row['duration'])
            if user_type == 'Subscriber':
                s = s + 1
                s_duration = s_duration + duration
            else:
                c = c + 1
                c_duration = c_duration + duration

        s_avg = s_duration/s
        c_avg = c_duration/c
        return (s,c,s_avg,c_avg)

data_file = ['../working//Washington-2016-Summary.csv', '../working//Chicago-2016-Summary.csv', '../working//NYC-2016-Summary.csv']
for datafile in data_file:
    s,c,s_avg,c_avg  = ridership(datafile)
    # print city name for reference
    city = datafile.split('-')[0].split('/')[-1]
    print("In "+city+" City: ")
    print("Average Ride Taken By Subscribers: "+ str(s_avg))
    print("Average Ride Taken By Customers  : "+ str(c_avg)+"\n")

import matplotlib.pyplot as plt
%matplotlib inline

plt.hist(data)
plt.title('Distribution of Trip Durations')
plt.xlabel('Duration (m)')
plt.show()
sns.set_style('whitegrid')

def plot_trip(filename):
    data = []
    with open(filename,'r') as fin:
        reader = csv.DictReader(fin)
        for row in reader:
            data.append(float(row['duration']))
        plt.hist(data)
        city = datafile.split('-')[0].split('/')[-1]
        plt.title(city)
        plt.xlabel("Trip Duration")
        plt.ylabel("No of Users")
        plt.show()

data_file = ['../working//Washington-2016-Summary.csv', '../working//Chicago-2016-Summary.csv', '../working//NYC-2016-Summary.csv']
for datafile in data_file:
    plot_trip(datafile)

import numpy as py
def plot_trip_again(filename):
    data = []
    with open(filename,'r') as fin:
        reader = csv.DictReader(fin)
        for row in reader:
            data.append(float(row['duration']))
        bins = py.arange(0,100,5)
        plt.hist(data,bins)
        city = datafile.split('-')[0].split('/')[-1]
        plt.title(city)
        plt.xlabel("Trip Duration")
        plt.ylabel("No of Users")
        plt.show()

data_file = ['../working//Washington-2016-Summary.csv', '../working//Chicago-2016-Summary.csv', '../working//NYC-2016-Summary.csv']
for datafile in data_file:
    plot_trip_again(datafile)


def plot_cus(filename):
    data1 = []
    with open(filename,'r') as fin:
        reader = csv.DictReader(fin)
        for row in reader:
            if row['user_type']=='Customer':
                if float(row['duration'])<75:
                    data1.append(float(row['duration']))

        bins = py.arange(0,80,5)
        plt.hist(data1,bins,histtype='bar',rwidth=0.8)
        plt.xticks(bins)
        city = datafile.split('-')[0].split('/')[-1]
        plt.title("Distribution of Trip Durations for Customer in " + city)
        plt.xlabel("Trip Duration")
        plt.ylabel("No of Users")
        plt.show()


data_file = ['../working//Washington-2016-Summary.csv', '../working//Chicago-2016-Summary.csv', '../working//NYC-2016-Summary.csv']
for datafile in data_file:
    plot_cus(datafile)


def monthly_analysis(filename):
    month_trip_sub={}
    month_trip_cus={}
    with open(filename,'r') as fin:
        reader = csv.DictReader(fin)
        data=[]
        data1=[]
        for i in range(1,13):
            month_trip_sub[str(i)]=0
            month_trip_cus[str(i)]=0
        for row in reader:
            if row['user_type']=='Subscriber':
                month_trip_sub[row['month']]+=1
            else:
                month_trip_cus[row['month']]+=1
        data = month_trip_sub.values()
        data1 = month_trip_cus.values()
        bins = py.arange(1,13,1)
        plt.bar(bins+0,data,width=0.4,label ='Subscriber')
        plt.bar(bins+.40,data1,width=0.4,label ='Customer')
        city = datafile.split('-')[0].split('/')[-1]
        plt.title("Monthly Analysis Of City " + city + " (Subscribers/Customer)")
        plt.xticks(bins,['Jan','Feb','Mar','Apr','may','Jun','July','Aug','Sep','Oct','Nov','Dec'])
        plt.xlabel("Month")
        plt.ylabel("No of Users")
        plt.legend()
        plt.show()

def total_trips_monthly(filename):
    total_trip_monthly = []
    total={}
    for i in range(1,13):
        total[str(i)]=0
    with open(filename,'r') as fin:
        reader = csv.DictReader(fin)
        for row in reader:
            total[row['month']]+=1
            #total_trip_monthly.append(int(row['month']))
        total_trip_monthly = total.values()
        bins = py.arange(1,13,1)
        #plt.hist(total_trip_monthly,bins,histtype='bar',rwidth=0.8)
        plt.bar(bins,total_trip_monthly,width=0.9)
        city = datafile.split('-')[0].split('/')[-1]
        plt.title("Monthly Analysis Of City " + city+ " (Total Users)")
        plt.xticks(bins,['Jan','Feb','Mar','Apr','may','Jun','July','Aug','Sep','Oct','Nov','Dec'])
        plt.xlabel("Month")
        plt.ylabel("No of Users")
        plt.show()

def ratio(filename):
    month_trip_sub={}
    month_trip_cus={}
    with open(filename,'r') as fin:
        reader = csv.DictReader(fin)
        data=[]
        data1=[]
        data2=[]
        for i in range(1,13):
            month_trip_sub[str(i)]=0
            month_trip_cus[str(i)]=0
        for row in reader:
            if row['user_type']=='Subscriber':
                month_trip_sub[row['month']]+=1
            else:
                month_trip_cus[row['month']]+=1
        for i in range(1,13):
            data.append(month_trip_sub[str(i)])
            data1.append(month_trip_cus[str(i)])
        for j in range(12):
            data2.append(data[j]/data1[j])
        bins = py.arange(1,13,1)
        plt.bar(bins,data2,width=0.6)
        city = datafile.split('-')[0].split('/')[-1]
        plt.title("Ratio Of (Subscriber/Customer) in " + city)
        plt.xticks(bins,['Jan','Feb','Mar','Apr','may','Jun','July','Aug','Sep','Oct','Nov','Dec'])
        plt.xlabel("Month")
        plt.ylabel("Ratio")
        plt.show()

data_file = ['../working//Washington-2016-Summary.csv', '../working//Chicago-2016-Summary.csv', '../working//NYC-2016-Summary.csv']
for datafile in data_file:
    total_trips_monthly(datafile)
    monthly_analysis(datafile)
    ratio(datafile)
